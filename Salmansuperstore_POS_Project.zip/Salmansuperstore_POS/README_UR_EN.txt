SALMANSUPERSTORE POS — Android project source
============================================

Features:
- Urdu + English labels
- Offline product inventory
- Purchase and selling prices, quantities, low-stock alert
- Single-item sale billing, estimated gross profit, payment type
- Sales history and daily / all-time totals
- Receipt print dialog (requires Android print service/browser support)
- JSON backup export and restore

IMPORTANT:
This archive contains the complete source project, not a precompiled APK.
An Android SDK/Gradle build environment is required to compile the APK.
No APK is claimed as built or tested in this environment.

Build APK:
1. Install Android Studio on a computer.
2. Open the extracted Salmansuperstore_POS folder as a project.
3. Allow Android Studio to install Android Gradle Plugin / SDK components.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output is normally app/build/outputs/apk/debug/app-debug.apk.

Use:
- Open app and add products first (name, buy price, sell price, stock).
- Go to Sale, select a product and quantity, then Complete Sale.
- Backup regularly using Export Backup.
- Data is stored locally on this device/browser app storage. Clearing app data or uninstalling can erase it; export a backup first.
- This starter POS records one product per sale. It is a basic shop tool, not a tax-compliance or audited accounting system.
